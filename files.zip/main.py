"""
AquaFresh – Smart Fish Marketplace
FastAPI Backend
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
import json
import os
from datetime import datetime

# Import route modules
from routes import auth, fish, orders, sellers, ai_pricing

app = FastAPI(
    title="AquaFresh API",
    description="Smart Fish Marketplace – Connecting buyers with local fishermen",
    version="1.0.0"
)

# CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount routes
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(fish.router, prefix="/api/fish", tags=["Fish Listings"])
app.include_router(orders.router, prefix="/api/orders", tags=["Orders"])
app.include_router(sellers.router, prefix="/api/sellers", tags=["Sellers"])
app.include_router(ai_pricing.router, prefix="/api/ai", tags=["AI Pricing"])

@app.get("/")
def root():
    return {
        "app": "AquaFresh – Smart Fish Marketplace",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
def health():
    return {"status": "healthy", "database": "connected"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
